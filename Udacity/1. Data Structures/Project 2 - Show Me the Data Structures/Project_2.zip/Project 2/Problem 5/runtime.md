
# Problem 4
### Blockchain


This was fun and interesting to see an actual use-case 
for LinkedList (especially in practice).

My answer contains a Block (or a Node class), and a Blockchain, which is
an implementation of a LinkedList. 

The time & space complexity of the add_block() is O(1).