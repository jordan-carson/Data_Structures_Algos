# Problem 6
### Union & Intersection

For the Union, I loop through both Lists
in two separate for loops, making the runtime
O(n^2) .

The intersection loops through all the items in the first
list and appends the item to a new LinkedList if that item
is contained in the second LikedList. Runtime O(n^2).

