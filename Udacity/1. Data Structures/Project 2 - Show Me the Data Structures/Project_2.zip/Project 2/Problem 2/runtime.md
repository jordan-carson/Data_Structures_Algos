# Problem 2
### Find Files

This problem is more easily solved using recursion
rather than iteration.

I decided to use the os (operating system) library which comes as part
of the Python Standard Library. 

We loop through all the specified path, we then determine
if the child paths are directories or files. If they are directories, we continue our recursion, otherwise we test
to determine if the files match our suffix. If it does, we add it to our list. 

The time complexity is O(n), where n is the number of files in the parent directory, and subsequent directories, files etc.
Separately, the space complexity is O(n), as we create a variable to hold the files that match the suffix. 


__Note:__ We can mitigate the recursion limit by setting

```python
import sys
sys.setrecursionlimit(100)
``` 