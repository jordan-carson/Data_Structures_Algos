# Problem 4
### Users / Groups

We are using recursion to solve this problem, because we are unsure how many 
groups we will have to search through. 

Here the time complexity is O(n), as we are looping through only one group.groups to find all subgroups. 

The space complexity is O(1) as we are only allocating one variable (boolean).
